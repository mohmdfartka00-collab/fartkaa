// قالب Edge Function لبدء الدفع بالبطاقة.
// لا تضع مفاتيح Paymob/Stripe السرية داخل ملفات الموقع أو JavaScript الخاص بالمتصفح.
// ضع الأسرار في Supabase Edge Function Secrets.
// الكود التالي يترك موضع التكامل مع مزود الدفع لأن بيانات حساب التاجر ومفاتيح API غير موجودة.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", {headers: cors()});
  try {
    const auth = req.headers.get("Authorization") || "";
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {global:{headers:{Authorization:auth}}});
    const {data:{user}} = await supabase.auth.getUser();
    if (!user) return json({message:"يجب تسجيل الدخول"},401);
    const {order_id} = await req.json();
    const {data:order,error}=await supabase.from("orders").select("id,total,payment_status,user_id").eq("id",order_id).eq("user_id",user.id).single();
    if(error||!order) return json({message:"الطلب غير موجود"},404);
    if(order.payment_status==="paid") return json({message:"الطلب مدفوع بالفعل"},400);

    // TODO: هنا يتم استدعاء API مزود الدفع (مثل Paymob) باستخدام الأسرار المخزنة في Secrets.
    // بعد إنشاء جلسة الدفع، أرجع رابط الدفع في checkout_url.
    // مثال النتيجة المطلوبة من الدالة:
    // return json({checkout_url:"https://provider.example/checkout/..."});
    return json({message:"بوابة الدفع لم تُفعّل بعد. أضف مفاتيح مزود الدفع ثم أكمل هذا التكامل."},501);
  } catch (e) { return json({message:e?.message||"خطأ غير متوقع"},500); }
});
function cors(){return {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};}
function json(body,status=200){return new Response(JSON.stringify(body),{status,headers:{...cors(),"Content-Type":"application/json"}});}
