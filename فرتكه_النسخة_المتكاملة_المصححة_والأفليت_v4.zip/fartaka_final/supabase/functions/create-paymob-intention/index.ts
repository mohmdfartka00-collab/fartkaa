import { createClient } from 'npm:@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { ...cors, 'Content-Type': 'application/json' } })
}

function adminKey() {
  const legacy = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  if (legacy) return legacy
  const keys = JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}')
  return keys.default || Object.values(keys)[0] as string
}

function splitName(name: string) {
  const parts = String(name || 'Customer').trim().split(/\s+/)
  return { first: parts.shift() || 'Customer', last: parts.join(' ') || 'Customer' }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  if (req.method !== 'POST') return json({ message: 'Method not allowed' }, 405)

  const auth = req.headers.get('Authorization') || ''
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : ''
  if (!token) return json({ message: 'تسجيل الدخول مطلوب' }, 401)

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const admin = createClient(supabaseUrl, adminKey())
  const userClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY') || Deno.env.get('SUPABASE_PUBLISHABLE_KEY') || '', {
    global: { headers: { Authorization: `Bearer ${token}` } },
  })
  const { data: { user }, error: userError } = await userClient.auth.getUser()
  if (userError || !user) return json({ message: 'جلسة الدخول غير صالحة' }, 401)

  const body = await req.json().catch(() => ({}))
  const orderId = body.order_id
  if (!orderId) return json({ message: 'order_id مطلوب' }, 400)

  const { data: order, error: orderError } = await admin.from('orders').select('*').eq('id', orderId).eq('user_id', user.id).maybeSingle()
  if (orderError || !order) return json({ message: 'الطلب غير موجود' }, 404)
  if (order.payment_status === 'paid') return json({ message: 'الطلب مدفوع بالفعل' }, 409)

  const { data: items, error: itemsError } = await admin.from('order_items').select('product_name,quantity,unit_price').eq('order_id', orderId)
  if (itemsError) return json({ message: itemsError.message }, 500)

  const secret = Deno.env.get('PAYMOB_SECRET_KEY')
  const publicKey = Deno.env.get('PAYMOB_PUBLIC_KEY')
  const integrationId = Number(Deno.env.get('PAYMOB_INTEGRATION_ID_CARD') || 0)
  const base = (Deno.env.get('PAYMOB_BASE_URL') || 'https://accept.paymob.com').replace(/\/$/, '')
  const appUrl = (Deno.env.get('APP_URL') || '').replace(/\/$/, '')
  if (!secret || !publicKey || !integrationId || !appUrl) return json({ message: 'بوابة الدفع غير مفعلة: أضف مفاتيح Paymob وAPP_URL في Secrets.' }, 503)

  const { data: profile } = await admin.from('profiles').select('full_name,phone,address,city').eq('id', user.id).maybeSingle()
  const name = splitName(profile?.full_name || user.user_metadata?.full_name || user.email?.split('@')[0] || 'Customer')
  const phone = profile?.phone || user.user_metadata?.phone || ''
  if (!phone) return json({ message: 'أضف رقم الهاتف في حسابك قبل الدفع.' }, 400)

  const totalCents = Math.round(Number(order.total) * 100)
  const itemLines = (items || []).map((x: any) => ({
    name: String(x.product_name).slice(0, 50),
    amount: Math.round(Number(x.unit_price) * 100) * Number(x.quantity),
    quantity: Number(x.quantity),
    description: 'منتج من فرتكه',
  }))
  const itemSum = itemLines.reduce((sum: number, x: any) => sum + x.amount, 0)
  // Paymob requires sum(items.amount) to equal total. With a coupon, omit items rather than sending a mismatched total.
  const safeItems = itemSum === totalCents ? itemLines : []

  const payload = {
    amount: totalCents,
    currency: 'EGP',
    payment_methods: [integrationId],
    ...(safeItems.length ? { items: safeItems } : {}),
    billing_data: {
      first_name: name.first,
      last_name: name.last,
      email: user.email || 'customer@example.com',
      phone_number: phone,
      apartment: 'NA', floor: 'NA', street: profile?.address || 'NA', building: 'NA',
      shipping_method: 'NA', postal_code: 'NA', city: profile?.city || 'NA', state: profile?.city || 'NA', country: 'EG',
    },
    customer: { first_name: name.first, last_name: name.last, email: user.email || 'customer@example.com' },
    special_reference: String(order.id),
    notification_url: `${appUrl}/functions/v1/paymob-webhook`,
    redirection_url: `${appUrl}/?payment=return&order_id=${encodeURIComponent(order.id)}`,
  }

  const response = await fetch(`${base}/v1/intention/`, {
    method: 'POST',
    headers: { Authorization: `Token ${secret}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  const result = await response.json().catch(() => ({}))
  if (!response.ok || !result.client_secret) {
    console.error('Paymob intention error', result)
    return json({ message: 'بوابة الدفع رفضت إنشاء عملية الدفع', details: result }, 502)
  }

  await admin.from('payment_transactions').insert({
    order_id: order.id,
    provider: 'paymob',
    provider_reference: result.id || result.intention_order_id?.toString(),
    amount: order.total,
    status: 'pending',
    raw_response: result,
  })
  await admin.from('orders').update({ payment_status: 'pending', payment_reference: result.id || null }).eq('id', order.id)

  const checkoutUrl = `${base}/unifiedcheckout/?publicKey=${encodeURIComponent(publicKey)}&clientSecret=${encodeURIComponent(result.client_secret)}`
  return json({ checkout_url: checkoutUrl, intention_id: result.id })
})
