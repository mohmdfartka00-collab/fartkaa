import { createClient } from 'npm:@supabase/supabase-js@2'

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } })
}
function bool(v: unknown) { return v === true ? 'true' : v === false ? 'false' : String(v ?? '') }
async function hmacSha512(secret: string, value: string) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-512' }, false, ['sign'])
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value))
  return [...new Uint8Array(sig)].map(x => x.toString(16).padStart(2, '0')).join('')
}
function safeEqual(a: string, b: string) {
  if (!a || a.length !== b.length) return false
  let n = 0; for (let i = 0; i < a.length; i++) n |= a.charCodeAt(i) ^ b.charCodeAt(i); return n === 0
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ message: 'Method not allowed' }, 405)
  const hmac = new URL(req.url).searchParams.get('hmac') || ''
  const body = await req.json().catch(() => ({}))
  const obj = body?.obj || {}
  const s = obj?.source_data || {}
  const fields = [
    obj.amount_cents, obj.created_at, obj.currency, obj.error_occured,
    obj.has_parent_transaction, obj.id, obj.integration_id, obj.is_3d_secure,
    obj.is_auth, obj.is_capture, obj.is_refunded, obj.is_standalone_payment,
    obj.is_voided, obj?.order?.id, obj.owner, obj.pending,
    s.pan, s.sub_type, s.type, obj.success,
  ].map(bool).join('')
  const secret = Deno.env.get('PAYMOB_HMAC_SECRET') || ''
  if (!secret) return json({ message: 'HMAC secret is not configured' }, 503)
  const expected = await hmacSha512(secret, fields)
  if (!safeEqual(expected, hmac.toLowerCase())) return json({ message: 'Invalid HMAC' }, 401)

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || (() => { const x = JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}'); return x.default || Object.values(x)[0] as string })()
  const admin = createClient(supabaseUrl, service)
  const internalOrderId = obj?.order?.merchant_order_id || obj?.merchant_order_id || obj?.payment_key_claims?.extra?.merchant_order_id || obj?.extras?.merchant_order_id
  if (!internalOrderId) return json({ received: true, ignored: 'missing internal order reference' })

  const { data: order } = await admin.from('orders').select('id,total,payment_status').eq('id', internalOrderId).maybeSingle()
  if (!order) return json({ received: true, ignored: 'unknown order' })

  const amount = Number(obj.amount_cents || 0) / 100
  if (Math.abs(amount - Number(order.total)) > 0.01) return json({ message: 'Amount mismatch' }, 400)

  const success = obj.success === true && obj.pending === false && obj.error_occured === false
  const newStatus = success ? 'paid' : (obj.pending === true ? 'pending' : 'failed')
  await admin.from('payment_transactions').update({ status: newStatus, raw_response: body, updated_at: new Date().toISOString() }).eq('order_id', order.id).eq('provider', 'paymob').eq('status', 'pending')
  if (success) {
    await admin.from('orders').update({ payment_status: 'paid', status: 'paid', payment_reference: String(obj.id || '') }).eq('id', order.id)
    await admin.from('shipping_events').insert({ order_id: order.id, status: 'paid', note: 'تم تأكيد الدفع من Paymob' })
  }
  return json({ received: true })
})
